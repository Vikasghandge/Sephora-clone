import React from "react";
import "./App.css";
import AllRoutes from "./All-Routes/AllRoutes";

/*
Dont make any changes to this file
*/

function App() {
  return (
    <>
      <AllRoutes />
    </>
  );
}

export default App;
