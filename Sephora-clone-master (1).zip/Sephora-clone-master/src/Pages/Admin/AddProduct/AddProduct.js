import React from 'react'
import Form from "./Form"
function AddProduct() {
  return (
    <div>
      <Form />
    </div>
  )
}

export default AddProduct
